$(document).ready(function() {
	$('#transferModalBtn').click(function(){$('#transferModal').modal('show')})
});